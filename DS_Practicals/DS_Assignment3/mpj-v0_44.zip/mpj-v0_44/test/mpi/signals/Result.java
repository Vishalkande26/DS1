package mpi.signals;

import java.io.*;
import mpi.*;

/**
 * The result is stored in a class which extends this class. That is what PoolServer returns after evaluation.
 */
public interface Result /* implements Serializable */ {
    //String toString();
}


